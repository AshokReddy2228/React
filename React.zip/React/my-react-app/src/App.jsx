import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Events from "./pages/Events";
import EventDetails from "./pages/EventDetails";
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import ModalRegister from "./components/ModalRegister";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import { AuthProvider } from "./context/AuthContext";
import { EventsProvider } from "./context/EventsContext";

function App() {
  return (
    <AuthProvider>
      <EventsProvider>
        <Router>
          <div className="min-h-screen flex flex-col">
            <Navbar />
            <main className="flex-grow container mx-auto p-4">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/events" element={<Events />} />
                <Route path="/events/:id" element={<EventDetails />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/login" element={<Login />} />
                <Route path="/Register" element={<ModalRegister />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </Router>
      </EventsProvider>
    </AuthProvider>
  );
}

export default App;
