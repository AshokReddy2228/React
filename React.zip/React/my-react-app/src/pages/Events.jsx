import React, { useContext } from "react";
import { EventsContext } from "../context/EventsContext";
import EventList from "../components/EventList";

export default function Events() {
  const { events } = useContext(EventsContext);

  const styles = {
    page: {
      maxWidth: "1200px",
      margin: "0 auto",
      padding: "50px 20px",
      fontFamily: "'Segoe UI', sans-serif",
      borderRadius: "20px",
      background: "linear-gradient(135deg, #f6d365, #fda085, #a1c4fd, #c2e9fb, #d4fc79, #96e6a1)",
      backgroundSize: "400% 400%",
      animation: "gradientAnimation 15s ease infinite",
      boxShadow: "0 10px 35px rgba(0,0,0,0.2)",
      color: "#fff",
    },
    title: {
      fontSize: "36px",
      fontWeight: "800",
      marginBottom: "10px",
      textShadow: "0 4px 15px rgba(0,0,0,0.35)",
    },
    subtitle: {
      fontSize: "20px",
      marginBottom: "35px",
      color: "#f0f0f0",
      textShadow: "0 2px 10px rgba(0,0,0,0.25)",
    },
  };

  return (
    <div style={styles.page}>
      <style>
        {`
          @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
          }
        `}
      </style>

      <h1 style={styles.title}>All Events</h1>
      <p style={styles.subtitle}>
        Explore all upcoming events and register easily.
      </p>
      <EventList events={events} />
    </div>
  );
}
