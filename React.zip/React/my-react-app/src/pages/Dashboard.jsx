import React from "react";
import { useEvents } from "../context/EventsContext";

export default function Dashboard() {
  const { registrations } = useEvents();

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>Dashboard</h1>
      <p>
        Total Registrations: <strong>{registrations.length}</strong>
      </p>

      {registrations.length > 0 && (
        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            marginTop: "20px",
          }}
        >
          <thead>
            <tr>
              <th style={tdStyle}>Full Name</th>
              <th style={tdStyle}>Date of Birth</th>
              <th style={tdStyle}>Gender</th>
              <th style={tdStyle}>Phone</th>
              <th style={tdStyle}>Email</th>
              <th style={tdStyle}>Heard From</th>
              <th style={tdStyle}>Event</th>
              <th style={tdStyle}>Tickets</th>
              <th style={tdStyle}>Payment Method</th>
              <th style={tdStyle}>Signature</th>
              <th style={tdStyle}>Date Signed</th>
            </tr>
          </thead>
          <tbody>
            {registrations.map((reg, index) => (
              <tr key={index}>
                <td style={tdStyle}>{reg.fullName}</td>
                <td style={tdStyle}>{reg.dob}</td>
                <td style={tdStyle}>{reg.gender}</td>
                <td style={tdStyle}>{reg.phone}</td>
                <td style={tdStyle}>{reg.email}</td>
                <td style={tdStyle}>
                  {reg.heardFrom === "Other" ? reg.heardOther : reg.heardFrom}
                </td>
                <td style={tdStyle}>{reg.selectedEvent}</td> {/* Fixed */}
                <td style={tdStyle}>{reg.tickets}</td>
                <td style={tdStyle}>{reg.paymentMethod}</td>
                <td style={tdStyle}>{reg.signature}</td>
                <td style={tdStyle}>{reg.dateSigned}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

const tdStyle = {
  border: "1px solid #ccc",
  padding: "8px",
  textAlign: "left",
};
