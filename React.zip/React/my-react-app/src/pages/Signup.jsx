import React, { useState } from "react";

export default function EventSignupForm({ onSignup }) {
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    agree: false,
  });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm({ ...form, [name]: type === "checkbox" ? checked : value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.fullName || !form.email || !form.password || !form.confirmPassword) {
      setError("Please fill in all required fields.");
      return;
    }
    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    if (!form.agree) {
      setError("You must agree to the terms and conditions.");
      return;
    }
    setError("");
    onSignup(form); // trigger signup action
  };

  const styles = {
    container: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      minHeight: "100vh",
      backgroundColor: "#f3f4f6",
      fontFamily: "'Segoe UI', sans-serif",
      padding: "20px",
    },
    card: {
      width: "100%",
      maxWidth: "450px",
      padding: "35px 30px",
      backgroundColor: "#fff",
      borderRadius: "12px",
      boxShadow: "0 4px 20px rgba(0,0,0,0.08)",
    },
    title: {
      fontSize: "26px",
      fontWeight: "700",
      color: "#333",
      textAlign: "center",
      marginBottom: "20px",
    },
    input: {
      width: "100%",
      padding: "12px 14px",
      marginBottom: "15px",
      border: "1px solid #d1d5db",
      borderRadius: "8px",
      fontSize: "15px",
      outline: "none",
      transition: "border 0.2s, box-shadow 0.2s",
    },
    inputFocus: {
      borderColor: "#4f46e5",
      boxShadow: "0 0 6px rgba(79,70,229,0.3)",
    },
    checkboxContainer: {
      display: "flex",
      alignItems: "center",
      marginBottom: "20px",
      fontSize: "14px",
      color: "#555",
    },
    button: {
      width: "100%",
      padding: "12px",
      backgroundColor: "#4f46e5",
      color: "#fff",
      fontSize: "16px",
      fontWeight: "600",
      border: "none",
      borderRadius: "8px",
      cursor: "pointer",
      transition: "background 0.2s",
    },
    buttonHover: {
      backgroundColor: "#4338ca",
    },
    error: {
      color: "#ef4444",
      fontSize: "14px",
      marginBottom: "12px",
      textAlign: "center",
    },
    link: {
      fontSize: "14px",
      color: "#4f46e5",
      textDecoration: "none",
      marginTop: "12px",
      display: "block",
      textAlign: "center",
    },
  };

  return (
    <div style={styles.container}>
      <form style={styles.card} onSubmit={handleSubmit}>
        <h2 style={styles.title}>Sign Up for Eventify</h2>

        {error && <div style={styles.error}>{error}</div>}

        <input
          type="text"
          name="fullName"
          placeholder="Full Name"
          value={form.fullName}
          onChange={handleChange}
          style={styles.input}
          onFocus={(e) => Object.assign(e.target.style, styles.inputFocus)}
          onBlur={(e) => Object.assign(e.target.style, styles.input)}
        />

        <input
          type="email"
          name="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
          style={styles.input}
          onFocus={(e) => Object.assign(e.target.style, styles.inputFocus)}
          onBlur={(e) => Object.assign(e.target.style, styles.input)}
        />

        <input
          type="text"
          name="phone"
          placeholder="Phone Number"
          value={form.phone}
          onChange={handleChange}
          style={styles.input}
          onFocus={(e) => Object.assign(e.target.style, styles.inputFocus)}
          onBlur={(e) => Object.assign(e.target.style, styles.input)}
        />

        <input
          type="password"
          name="password"
          placeholder="Password"
          value={form.password}
          onChange={handleChange}
          style={styles.input}
          onFocus={(e) => Object.assign(e.target.style, styles.inputFocus)}
          onBlur={(e) => Object.assign(e.target.style, styles.input)}
        />

        <input
          type="password"
          name="confirmPassword"
          placeholder="Confirm Password"
          value={form.confirmPassword}
          onChange={handleChange}
          style={styles.input}
          onFocus={(e) => Object.assign(e.target.style, styles.inputFocus)}
          onBlur={(e) => Object.assign(e.target.style, styles.input)}
        />

        <label style={styles.checkboxContainer}>
          <input
            type="checkbox"
            name="agree"
            checked={form.agree}
            onChange={handleChange}
            style={{ marginRight: "8px" }}
          />
          I agree to the <a href="/terms" style={{ color: "#4f46e5" }}>terms & conditions</a>
        </label>

        <button
          type="submit"
          style={styles.button}
          onMouseOver={(e) => Object.assign(e.target.style, styles.buttonHover)}
          onMouseOut={(e) => Object.assign(e.target.style, styles.button)}
        >
          Sign Up
        </button>

        <a href="/login" style={styles.link}>
          Already have an account? Login
        </a>
      </form>
    </div>
  );
}
