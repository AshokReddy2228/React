import React, { useState } from "react";

// --- LOGIN FORM ---
function EventLoginForm({ onLogin }) {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onLogin(form, setError);
  };

  return (
    <div style={loginContainer}>
      <h2 style={loginTitle}>Login</h2>

      <form onSubmit={handleSubmit} style={loginForm}>
        <label>Email</label>
        <input
          type="email"
          name="email"
          style={input}
          value={form.email}
          onChange={handleChange}
        />

        <label>Password</label>
        <input
          type="password"
          name="password"
          style={input}
          value={form.password}
          onChange={handleChange}
        />

        {error && <p style={{ color: "red" }}>{error}</p>}

        <button type="submit" style={buttonStyle}>Login</button>
      </form>
    </div>
  );
}

// --- LOGIN UI STYLES ---
const loginContainer = {
  width: "400px",
  margin: "80px auto",
  padding: "30px",
  background: "rgba(255,255,255,0.9)",
  borderRadius: "12px",
  boxShadow: "0px 5px 20px rgba(0,0,0,0.2)",
  fontFamily: "'Segoe UI', sans-serif",
};

const loginTitle = {
  textAlign: "center",
  marginBottom: "20px",
};

const loginForm = {
  display: "flex",
  flexDirection: "column",
};

const input = {
  padding: "10px",
  marginBottom: "15px",
  borderRadius: "8px",
  border: "1px solid #ccc",
};

const buttonStyle = {
  padding: "12px",
  background: "linear-gradient(45deg, #6a11cb, #2575fc)",
  border: "none",
  borderRadius: "8px",
  color: "#fff",
  fontSize: "16px",
  cursor: "pointer",
};

// --- APP (LOGIN ONLY) ---
export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const validCredentials = {
    email: "ashok@gmail.com",
    password: "12345",
  };

  const handleLogin = (formData, setError) => {
    const { email, password } = formData;

    if (email === validCredentials.email && password === validCredentials.password) {
      setIsLoggedIn(true);
    } else {
      setError("Invalid login credentials!");
    }
  };

  return (
    <div>
      {!isLoggedIn ? (
        <EventLoginForm onLogin={handleLogin} />
      ) : (
        <h2 style={{ textAlign: "center", marginTop: "100px" }}>
          ✅ Login Successful!
        </h2>
      )}
    </div>
  );
}
