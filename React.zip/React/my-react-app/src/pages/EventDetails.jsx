import React, { useContext, useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { EventsContext } from "../context/EventsContext";
import ModalRegister from "../components/ModalRegister";

export default function EventDetails() {
  const { id } = useParams();
  const { events } = useContext(EventsContext);
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    if (events && events.length > 0) {
      const found = events.find((e) => e.id === parseInt(id));
      setEvent(found || null);
      setLoading(false);
    }
  }, [events, id]);

  if (loading)
    return (
      <div style={{ padding: "50px", textAlign: "center", fontSize: "20px" }}>
        Loading event...
      </div>
    );

  if (!event)
    return (
      <div
        style={{
          padding: "50px",
          textAlign: "center",
          color: "#ff4d4f",
          fontFamily: "'Segoe UI', sans-serif",
          fontSize: "22px",
          fontWeight: "600",
        }}
      >
        Event not found
      </div>
    );

  const styles = {
    page: {
      maxWidth: "900px",
      margin: "40px auto",
      padding: "20px",
      fontFamily: "'Segoe UI', sans-serif",
      borderRadius: "20px",
      background:
        "linear-gradient(135deg, #ff9a9e, #fad0c4, #fbc2eb, #a18cd1, #f6d365, #fda085)",
      backgroundSize: "400% 400%",
      animation: "gradientAnimation 12s ease infinite",
      boxShadow: "0 10px 35px rgba(0,0,0,0.25)",
      color: "#222",
      textAlign: "center",
    },
    image: {
      width: "100%",
      height: "400px",
      objectFit: "cover",
      borderRadius: "16px",
      boxShadow: "0 6px 25px rgba(0,0,0,0.2)",
      marginBottom: "25px",
      transition: "transform 0.3s ease, box-shadow 0.3s ease",
    },
    imageHover: {
      transform: "scale(1.03)",
      boxShadow: "0 12px 40px rgba(0,0,0,0.3)",
    },
    title: {
      fontSize: "36px",
      fontWeight: "800",
      color: "#fff",
      marginBottom: "12px",
      textShadow: "0 4px 15px rgba(0,0,0,0.4)",
    },
    category: {
      fontSize: "16px",
      fontWeight: "600",
      color: "#fff",
      marginBottom: "20px",
      textShadow: "0 3px 10px rgba(0,0,0,0.35)",
    },
    description: {
      fontSize: "18px",
      lineHeight: "1.7",
      color: "#fff",
      marginBottom: "30px",
      textShadow: "0 2px 8px rgba(0,0,0,0.25)",
    },
    registerBtn: {
      padding: "14px 28px",
      background:
        "linear-gradient(45deg, #6a11cb, #2575fc, #43e97b, #38f9d7)",
      color: "#fff",
      borderRadius: "10px",
      fontSize: "18px",
      fontWeight: "700",
      cursor: "pointer",
      border: "none",
      boxShadow: "0 6px 20px rgba(0,0,0,0.25)",
      transition: "all 0.3s ease",
      marginTop: "20px",
    },
    registerHover: {
      transform: "translateY(-3px) scale(1.03)",
      boxShadow: "0 10px 30px rgba(0,0,0,0.35)",
      background:
        "linear-gradient(45deg, #38f9d7, #43e97b, #2575fc, #6a11cb)",
    },
  };

  return (
    <div style={styles.page}>
      <style>
        {`
          @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
          }
        `}
      </style>

      <img
        src={event.image}
        alt={event.title}
        style={styles.image}
        onMouseOver={(e) => Object.assign(e.currentTarget.style, styles.imageHover)}
        onMouseOut={(e) => Object.assign(e.currentTarget.style, styles.image)}
      />

      <h1 style={styles.title}>{event.title}</h1>
      <p style={styles.category}>
        {event.category} • {event.venue} • {new Date(event.datetime).toLocaleString()}
      </p>

      <p style={styles.description}>{event.description || "No description available."}</p>

      <button
        style={styles.registerBtn}
        onMouseOver={(e) => Object.assign(e.target.style, styles.registerHover)}
        onMouseOut={(e) => Object.assign(e.target.style, styles.registerBtn)}
        onClick={() => setShowModal(true)}
      >
        Register for Event
      </button>

      {showModal && <ModalRegister event={event} onClose={() => setShowModal(false)} />}
    </div>
  );
}
