export const sampleEvents = [
  {
    id: 'e1',
    title: 'React Workshop',
    description: 'Learn React basics, hooks, and building reusable components.',
    category: 'Workshops',
    datetime: '2025-12-05T14:00:00',
    venue: 'Online',
    deadline: '2025-12-04',
    image: 'https://reactjs.jpg'
  },
  {
    id: 'e2',
    title: 'City Marathon',
    description: '5K and 10K runs for all ages. Join and compete for fun prizes.',
    category: 'Sports',
    datetime: '2025-12-20T06:00:00',
    venue: 'City Stadium',
    deadline: '2025-12-15',
    image: 'https://City.jpeg'
  },
  {
    id: 'e3',
    title: 'Photography Masterclass',
    description: 'Professional photographers teach lighting, editing, and composition.',
    category: 'Workshops',
    datetime: '2025-12-10T10:00:00',
    venue: 'Art Center, Hall A',
    deadline: '2025-12-08',
    image: 'https://ArtCenter.jpeg'
  },
  {
    id: 'e4',
    title: 'Jazz Night',
    description: 'Enjoy live jazz performances with local and international artists.',
    category: 'Music',
    datetime: '2025-12-15T19:00:00',
    venue: 'Downtown Concert Hall',
    deadline: '2025-12-14',
    image: 'https://Music.jpeg'
  },
  {
    id: 'e5',
    title: 'Tech Career Fair',
    description: 'Meet top tech companies, network, and attend career workshops.',
    category: 'Networking',
    datetime: '2025-12-18T09:00:00',
    venue: 'Convention Center',
    deadline: '2025-12-16',
    image: 'https://ConventionCenter.jpeg'
  },
  {
    id: 'e6',
    title: 'Food Festival',
    description: 'Taste delicious dishes from around the world in one place.',
    category: 'Food & Drink',
    datetime: '2025-12-22T12:00:00',
    venue: 'Central Park',
    deadline: '2025-12-20',
    image: 'https://FoodDrink.png'
  },
  {
    id: 'e7',
    title: 'Yoga & Wellness Retreat',
    description: 'Relax and rejuvenate with yoga sessions and wellness talks.',
    category: 'Health & Wellness',
    datetime: '2025-12-28T08:00:00',
    venue: 'Mountain Resort',
    deadline: '2025-12-25',
    image: 'https://MountainResort.jpg'
  },
];
