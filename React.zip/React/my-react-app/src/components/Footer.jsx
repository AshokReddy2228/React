import React from "react";

export default function Footer() {
  const styles = {
    footer: {
      background: "linear-gradient(90deg, #4f46e5, #7c3aed, #ec4899, #f43f5e, #ef4444)",
      backgroundSize: "400% 400%",
      animation: "footerGradient 12s ease infinite",
      color: "#ffffff",
      padding: "50px 20px",
      textAlign: "center",
      fontFamily: "'Segoe UI', sans-serif",
      borderTop: "4px solid rgba(255,255,255,0.3)",
      boxShadow: "0 -4px 12px rgba(0,0,0,0.25)",
    },
    text: {
      margin: "0 0 12px 0",
      fontSize: "15px",
      opacity: 0.9,
      textShadow: "0 1px 4px rgba(0,0,0,0.3)",
    },
    socials: {
      display: "flex",
      justifyContent: "center",
      gap: "22px",
      marginTop: "12px",
    },
    socialIcon: {
      width: "36px",
      height: "36px",
      borderRadius: "50%",
      backgroundColor: "rgba(255,255,255,0.85)",
      color: "#4f46e5",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontWeight: "bold",
      cursor: "pointer",
      transition: "all 0.3s ease",
      boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
    },
    socialHover: {
      backgroundColor: "#00000050",
      color: "#fff",
      transform: "scale(1.15)",
      boxShadow: "0 4px 12px rgba(0,0,0,0.35)",
    },
  };

  return (
    <footer style={styles.footer}>
      {/* Animated Gradient Keyframes */}
      <style>
        {`
        @keyframes footerGradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}
      </style>

      <p style={styles.text}>© 2025 Eventify. All Rights Reserved.</p>

      <div style={styles.socials}>
        {["F", "T", "I", "L"].map((icon) => (
          <div
            key={icon}
            style={styles.socialIcon}
            onMouseOver={(e) => Object.assign(e.currentTarget.style, styles.socialHover)}
            onMouseOut={(e) => Object.assign(e.currentTarget.style, styles.socialIcon)}
          >
            {icon}
          </div>
        ))}
      </div>
    </footer>
  );
}
