import React, { useState } from "react";
import EventCard from "./EventCard";

export default function EventList({ events }) {
  const [category, setCategory] = useState("all");
  const [query, setQuery] = useState("");

  const styles = {
    container: {
      maxWidth: "1200px",
      margin: "40px auto",
      padding: "20px",
      borderRadius: "20px",
      background: "linear-gradient(135deg, #fbc2eb, #a6c1ee, #fad0c4, #ffd1ff, #96fbc4)",
      backgroundSize: "400% 400%",
      animation: "gradientAnimation 15s ease infinite",
      boxShadow: "0 10px 35px rgba(0,0,0,0.2)",
      color: "#fff",
      fontFamily: "'Segoe UI', sans-serif",
    },
    filterBox: {
      background: "rgba(255, 255, 255, 0.15)",
      backdropFilter: "blur(10px)",
      padding: "14px 20px",
      borderRadius: "12px",
      boxShadow: "0 4px 20px rgba(0,0,0,0.15)",
      display: "flex",
      alignItems: "center",
      gap: "20px",
      marginBottom: "25px",
    },
    select: {
      padding: "10px 14px",
      borderRadius: "8px",
      border: "1px solid rgba(255,255,255,0.6)",
      fontSize: "15px",
      cursor: "pointer",
      background: "rgba(255,255,255,0.2)",
      color: "#fff",
    },
    search: {
      flex: 1,
      padding: "10px 14px",
      borderRadius: "8px",
      border: "1px solid rgba(255,255,255,0.6)",
      fontSize: "15px",
      background: "rgba(255,255,255,0.2)",
      color: "#fff",
    },
    grid: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
      gap: "24px",
      marginTop: "20px",
    },
    heading: {
      fontSize: "28px",
      fontWeight: "800",
      marginBottom: "20px",
      color: "#fff",
      textShadow: "0 3px 10px rgba(0,0,0,0.4)",
    },
    noEvents: {
      color: "#fff",
      fontSize: "18px",
      textAlign: "center",
      marginTop: "40px",
    }
  };

  // Filtering logic
  const filteredEvents = events.filter((e) => {
    const matchCategory = category === "all" || e.category === category;
    const matchQuery = e.title.toLowerCase().includes(query.toLowerCase());
    return matchCategory && matchQuery;
  });

  return (
    <div style={styles.container}>
      <style>
        {`
          @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
          }
        `}
      </style>

      <h2 style={styles.heading}>Upcoming Events</h2>

      {/* Filter Bar */}
      <div style={styles.filterBox}>
        <select
          style={styles.select}
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="all">All Categories</option>
          <option value="music">Music</option>
          <option value="conference">Conference</option>
          <option value="sports">Sports</option>
          <option value="workshop">Workshop</option>
        </select>

        <input
          type="text"
          placeholder="Search events..."
          style={styles.search}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      {/* Event Grid */}
      <div style={styles.grid}>
        {filteredEvents.length > 0 ? (
          filteredEvents.map((event) => (
            <EventCard key={event.id} event={event} />
          ))
        ) : (
          <p style={styles.noEvents}>No events found.</p>
        )}
      </div>
    </div>
  );
}
