import React, { useState } from "react";
import { useEvents } from "../context/EventsContext";

export default function EventRegistrationForm() {
  const { addRegistration } = useEvents(); // get addRegistration from context

  // List of events
  const [events] = useState([
    {
      id: "e1",
      title: "React Workshop",
      description: "Learn React basics, hooks, and building reusable components.",
      category: "Workshops",
      datetime: "2025-12-05T14:00:00",
      venue: "Online",
      deadline: "2025-12-04",
      image: "https://reactjs.jpg",
    },
    {
      id: "e2",
      title: "City Marathon",
      description: "5K and 10K runs for all ages. Join and compete for fun prizes.",
      category: "Sports",
      datetime: "2025-12-20T06:00:00",
      venue: "City Stadium",
      deadline: "2025-12-15",
      image: "https://City.jpeg",
    },
    {
      id: "e3",
      title: "Photography Masterclass",
      description:
        "Professional photographers teach lighting, editing, and composition.",
      category: "Workshops",
      datetime: "2025-12-10T10:00:00",
      venue: "Art Center, Hall A",
      deadline: "2025-12-08",
      image: "https://ArtCenter.jpeg",
    },
    {
      id: "e4",
      title: "Jazz Night",
      description: "Enjoy live jazz performances with local and international artists.",
      category: "Music",
      datetime: "2025-12-15T19:00:00",
      venue: "Downtown Concert Hall",
      deadline: "2025-12-14",
      image: "https://Music.jpeg",
    },
    {
      id: "e5",
      title: "Tech Career Fair",
      description:
        "Meet top tech companies, network, and attend career workshops.",
      category: "Networking",
      datetime: "2025-12-18T09:00:00",
      venue: "Convention Center",
      deadline: "2025-12-16",
      image: "https://ConventionCenter.jpeg",
    },
    {
      id: "e6",
      title: "Food Festival",
      description: "Taste delicious dishes from around the world in one place.",
      category: "Food & Drink",
      datetime: "2025-12-22T12:00:00",
      venue: "Central Park",
      deadline: "2025-12-20",
      image: "https://FoodDrink.png",
    },
    {
      id: "e7",
      title: "Yoga & Wellness Retreat",
      description:
        "Relax and rejuvenate with yoga sessions and wellness talks.",
      category: "Health & Wellness",
      datetime: "2025-12-28T08:00:00",
      venue: "Mountain Resort",
      deadline: "2025-12-25",
      image: "https://MountainResort.jpg",
    },
  ]);

  const [form, setForm] = useState({
    selectedEvent: "",
    fullName: "",
    dob: "",
    gender: "",
    phone: "",
    email: "",
    heardFrom: "",
    heardOther: "",
    tickets: "",
    paymentMethod: "",
    signature: "",
    dateSigned: "",
    agree: false,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm({ ...form, [name]: type === "checkbox" ? checked : value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.selectedEvent) {
      alert("Please select an event.");
      return;
    }
    if (!form.agree) {
      alert("You must agree to participate.");
      return;
    }
    addRegistration(form); // add registration to context
    alert("Form Submitted!");
    setForm({
      selectedEvent: "",
      fullName: "",
      dob: "",
      gender: "",
      phone: "",
      email: "",
      heardFrom: "",
      heardOther: "",
      tickets: "",
      paymentMethod: "",
      signature: "",
      dateSigned: "",
      agree: false,
    });
  };

  const selectedEventDetails = events.find(
    (e) => e.title === form.selectedEvent
  );

  return (
    <div style={{ maxWidth: "800px", margin: "0 auto", fontFamily: "Arial" }}>
      <h1 style={{ textAlign: "center" }}>Event Registration Form</h1>

      {/* EVENT SELECTION */}
      <section>
        <h3>Select Event</h3>
        <select
          name="selectedEvent"
          value={form.selectedEvent}
          onChange={handleChange}
          style={input}
        >
          <option value="">-- Select an Event --</option>
          {events.map((event) => (
            <option key={event.id} value={event.title}>
              {event.title}
            </option>
          ))}
        </select>
      </section>

      {/* EVENT DETAILS */}
      {selectedEventDetails && (
        <section>
          <h3>About This Event</h3>
          <table
            style={{
              width: "100%",
              borderCollapse: "collapse",
              marginBottom: "20px",
            }}
          >
            <tbody>
              <tr>
                <td style={tdStyle}>Event Name</td>
                <td style={tdStyle}>{selectedEventDetails.title}</td>
              </tr>
              <tr>
                <td style={tdStyle}>Date & Time</td>
                <td style={tdStyle}>
                  {new Date(selectedEventDetails.datetime).toLocaleString()}
                </td>
              </tr>
              <tr>
                <td style={tdStyle}>Venue</td>
                <td style={tdStyle}>{selectedEventDetails.venue}</td>
              </tr>
              <tr>
                <td style={tdStyle}>Description</td>
                <td style={tdStyle}>{selectedEventDetails.description}</td>
              </tr>
              <tr>
                <td style={tdStyle}>Category</td>
                <td style={tdStyle}>{selectedEventDetails.category}</td>
              </tr>
            </tbody>
          </table>
        </section>
      )}

      {/* PARTICIPANT INFORMATION */}
      <form onSubmit={handleSubmit}>
        <h3>Participant Information</h3>

        <div style={row}>
          <div style={col}>
            <label>Full Name</label>
            <input
              style={input}
              name="fullName"
              value={form.fullName}
              onChange={handleChange}
            />
          </div>
          <div style={col}>
            <label>Date of Birth</label>
            <input
              type="date"
              style={input}
              name="dob"
              value={form.dob}
              onChange={handleChange}
            />
          </div>
        </div>

        <div style={row}>
          <div style={col}>
            <label>Gender</label>
            <div>
              <input
                type="radio"
                name="gender"
                value="Male"
                onChange={handleChange}
              />{" "}
              Male{" "}
              <input
                type="radio"
                name="gender"
                value="Female"
                onChange={handleChange}
              />{" "}
              Female
            </div>
          </div>

          <div style={col}>
            <label>Phone Number</label>
            <input
              style={input}
              name="phone"
              value={form.phone}
              onChange={handleChange}
            />
          </div>

          <div style={col}>
            <label>Email</label>
            <input
              style={input}
              name="email"
              value={form.email}
              onChange={handleChange}
            />
          </div>
        </div>

        <label>Where did you hear about this event?</label>
        <div>
          {["Facebook", "Youtube", "Instagram", "Twitter"].map((item) => (
            <label key={item} style={{ marginRight: "15px" }}>
              <input
                type="radio"
                name="heardFrom"
                value={item}
                onChange={handleChange}
              />{" "}
              {item}
            </label>
          ))}
          <label>
            <input
              type="radio"
              name="heardFrom"
              value="Other"
              onChange={handleChange}
            />{" "}
            Other:
          </label>
          <input
            style={{ marginLeft: "10px", padding: "5px" }}
            name="heardOther"
            value={form.heardOther}
            onChange={handleChange}
            placeholder="Specify"
          />
        </div>

        {/* PAYMENT INFORMATION */}
        <h3 style={{ marginTop: "20px" }}>Payment Information</h3>

        <label>Number of Tickets</label>
        <input
          style={input}
          name="tickets"
          value={form.tickets}
          onChange={handleChange}
        />

        <label>Payment Method</label>
        <div>
          {["Credit Card", "Debit Card", "Cash", "Check"].map((m) => (
            <label key={m} style={{ marginRight: "15px" }}>
              <input
                type="radio"
                name="paymentMethod"
                value={m}
                onChange={handleChange}
              />{" "}
              {m}
            </label>
          ))}
        </div>

        <p style={{ marginTop: "10px", fontSize: "14px" }}>
          I understand that participation in this event may involve some degree
          of risk. I release WebinarPros LLC from any liability for injury,
          loss, or damage to personal property.
        </p>

        <label>
          <input
            type="checkbox"
            name="agree"
            checked={form.agree}
            onChange={handleChange}
          />{" "}
          Yes, I understand.
        </label>

        <div style={row}>
          <div style={col}>
            <label>Signature</label>
            <input
              style={input}
              name="signature"
              value={form.signature}
              onChange={handleChange}
            />
          </div>
          <div style={col}>
            <label>Date Signed</label>
            <input
              type="date"
              style={input}
              name="dateSigned"
              value={form.dateSigned}
              onChange={handleChange}
            />
          </div>
        </div>

        <button
          type="submit"
          style={{
            marginTop: "20px",
            padding: "10px 20px",
            background: "#1a73e8",
            color: "white",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          Submit
        </button>
      </form>
    </div>
  );
}

// STYLES
const input = {
  padding: "8px",
  width: "100%",
  marginBottom: "10px",
  border: "1px solid #ccc",
  borderRadius: "5px",
};

const row = { display: "flex", gap: "15px", marginBottom: "15px" };
const col = { flex: 1 };
const tdStyle = { border: "1px solid #ccc", padding: "8px" };
