import React from "react";
import { Link } from "react-router-dom";

export default function EventCard({ event }) {
  const styles = {
    card: {
      borderRadius: "16px",
      overflow: "hidden",
      background: "linear-gradient(135deg, #f6d365, #fda085, #f093fb, #6a11cb, #2575fc)",
      boxShadow: "0 5px 20px rgba(0,0,0,0.15)",
      transition: "transform 0.3s ease, box-shadow 0.3s ease, background 0.5s ease",
      cursor: "pointer",
    },
    cardHover: {
      transform: "translateY(-8px) scale(1.02)",
      boxShadow: "0 12px 30px rgba(0,0,0,0.25)",
      background: "linear-gradient(135deg, #2575fc, #6a11cb, #f093fb, #fda085, #f6d365)",
    },
    img: {
      width: "100%",
      height: "180px",
      objectFit: "cover",
      borderTopLeftRadius: "16px",
      borderTopRightRadius: "16px",
      transition: "transform 0.3s ease",
    },
    content: {
      padding: "18px",
      backgroundColor: "rgba(255, 255, 255, 0.95)",
      backdropFilter: "blur(4px)",
    },
    title: {
      fontSize: "20px",
      fontWeight: "700",
      color: "#222",
      marginBottom: "8px",
    },
    dateBadge: {
      background: "linear-gradient(90deg, #6a11cb, #2575fc)",
      color: "#fff",
      padding: "6px 14px",
      borderRadius: "8px",
      fontSize: "13px",
      fontWeight: "600",
      display: "inline-block",
      marginBottom: "12px",
      textShadow: "1px 1px 3px rgba(0,0,0,0.2)",
    },
    info: {
      fontSize: "14px",
      color: "#555",
      marginBottom: "6px",
    },
    bottomBar: {
      marginTop: "16px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
    },
    price: {
      fontSize: "16px",
      fontWeight: "700",
      color: "#111",
    },
    button: {
      background: "linear-gradient(45deg, #6a11cb, #2575fc)",
      padding: "9px 16px",
      color: "white",
      borderRadius: "8px",
      fontSize: "14px",
      textDecoration: "none",
      transition: "all 0.3s ease",
      boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
    },
    buttonHover: {
      background: "linear-gradient(45deg, #2575fc, #6a11cb)",
      transform: "translateY(-2px)",
      boxShadow: "0 6px 16px rgba(0,0,0,0.3)",
    },
  };

  return (
    <div
      style={styles.card}
      onMouseOver={(e) => Object.assign(e.currentTarget.style, styles.cardHover)}
      onMouseOut={(e) => Object.assign(e.currentTarget.style, styles.card)}
    >
      <img src={event.image} alt={event.title} style={styles.img} />

      <div style={styles.content}>
        <span style={styles.dateBadge}>
          {new Date(event.datetime).toLocaleString()}
        </span>

        <h3 style={styles.title}>{event.title}</h3>

        <p style={styles.info}><strong>Category:</strong> {event.category}</p>
        <p style={styles.info}><strong>Venue:</strong> {event.venue}</p>
        <p style={styles.info}><strong>Attendees:</strong> {event.attendees || 0}</p>

        <div style={styles.bottomBar}>
          <span style={styles.price}>${event.price || "Free"}</span>

          <Link
            to={`/events/${event.id}`}
            style={styles.button}
            onMouseOver={(e) => Object.assign(e.target.style, styles.buttonHover)}
            onMouseOut={(e) => Object.assign(e.target.style, styles.button)}
          >
            Details
          </Link>
        </div>
      </div>
    </div>
  );
}
