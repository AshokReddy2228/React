import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useContext(AuthContext);

  const styles = {
    nav: {
      width: "100vw",
      background: "linear-gradient(90deg, #4f46e5, #7c3aed, #ec4899, #f43f5e)",
      backgroundSize: "400% 400%",
      animation: "gradientAnimation 12s ease infinite",
      padding: "15px 40px",
      position: "sticky",
      top: 0,
      zIndex: 1000,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      left: 0,
      boxShadow: "0 4px 12px rgba(0, 0, 0, 0.2)",
    },
    logo: {
      fontSize: "28px",
      fontWeight: "800",
      textDecoration: "none",
      color: "#fff",
      letterSpacing: "1px",
      textShadow: "0 2px 6px rgba(0,0,0,0.3)",
    },
    navLinks: {
      display: "flex",
      gap: "20px",
      alignItems: "center",
      marginRight: "60px",
    },
    link: {
      textDecoration: "none",
      color: "#f1f1f1",
      fontSize: "17px",
      padding: "8px 12px",
      borderRadius: "6px",
      transition: "0.3s ease",
    },
    button: {
      padding: "8px 16px",
      backgroundColor: "rgba(255,255,255,0.2)",
      color: "#fff",
      border: "1px solid rgba(255,255,255,0.4)",
      borderRadius: "6px",
      fontSize: "15px",
      cursor: "pointer",
      transition: "0.3s ease",
      backdropFilter: "blur(4px)",
    },
  };

  return (
    <>
      <nav style={styles.nav}>
        <style>
          {`
          @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
          }

          nav a:hover {
            background-color: rgba(255, 255, 255, 0.25) !important;
            color: #fff !important;
          }

          nav button:hover {
            background-color: rgba(255,255,255,0.35) !important;
          }
          `}
        </style>

        <Link to="/" style={styles.logo}>Eventify</Link>

        <div style={styles.navLinks}>
          <Link to="/events" style={styles.link}>Events</Link>
          <Link to="/dashboard" style={styles.link}>Dashboard</Link>
          <Link to="/register" style={styles.link}>Register</Link> {/* Added Register button */}

          {user ? (
            <button style={styles.button} onClick={logout}>
              Logout
            </button>
          ) : (
            <Link to="/login" style={styles.link}>
              Login
            </Link>
          )}
        </div>
      </nav>
    </>
  );
}
