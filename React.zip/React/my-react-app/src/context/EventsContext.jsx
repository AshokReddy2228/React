import { createContext, useContext, useState } from "react";

const EventsContext = createContext();

export const EventsProvider = ({ children }) => {
  const [registrations, setRegistrations] = useState([]); // store registration data

  const addRegistration = (formData) => {
    setRegistrations((prev) => [...prev, formData]);
  };

  return (
    <EventsContext.Provider value={{ registrations, addRegistration }}>
      {children}
    </EventsContext.Provider>
  );
};

export const useEvents = () => useContext(EventsContext);
